package Trabajo25;

import java.util.Scanner;
import java.net.Socket;
import java.io.IOException;

public class Main {
    public static boolean Puerto(String host, int puerto) {
        try (Socket socket = new Socket(host, puerto)) {
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        String host;
        int[] puertos = {21, 22 ,80, 443};

        while (true) {
            System.out.println("Introduce una dirección IP (o escribe 'localhost') o 'salir' para terminar la conexión:");
            host = sc.nextLine().trim();

            if (host.equalsIgnoreCase("salir")) {
                System.out.println("Saliendo del programa");
                break;
            }
            System.out.println("Puertos disponibles: 21, 22, 80, 443.");
            String eleccion = sc.nextLine().trim();

            if (eleccion.equals("famosos")) {
                System.out.println("Escaneando puertos...");
                for (int puerto : puertos) {
                    boolean abierto = Puerto(host, puerto);
                    System.out.printf("Puerto %d (%s): %s%n",
                            puerto,
                            (puerto == 21 ? "FTP" :
                             puerto == 22 ? "SSH" :
                             puerto == 80 ? "HTTP" :
                             puerto == 443 ? "HTTPS" : ""),
                            abierto ? "Puerto abierto" : "Puerto cerrado");
                }
            } else if (eleccion.equals("especifico")) {
                System.out.print("Introduce el número del puerto que quieras: ");
                try {
                    int puerto = Integer.parseInt(sc.nextLine());
                    boolean abierto = Puerto(host, puerto);
                    System.out.printf("Puerto %d: %s%n", puerto, abierto ? "Puerto abierto" : "Puerto cerrado");
                } catch (NumberFormatException e) {
                    System.out.println("Número de puerto inválido. Intenta de nuevo");
                }
            } else {
                System.out.println("Opción no válida. Intenta de nuevo");
            }
        }
        sc.close();
    }
}


